package test;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;


public class SqlTest {

    public static void main(String[] args)  {
    	try{
    		
    		Workbook workbook = Workbook.getWorkbook(new File("D://sql.xls"));
    		
    		System.out.println("开始");
    		
    		List<Table> list = importExcel(workbook,1);
    		
    		System.out.println("已获得集合:输出table");
    		
    		for(Table t:list){
    			
    			 System.out.println(createSql(t.getTableName(),t.getColumnStr(),null,t.getTypeStr(),t.getContentStr()));
    		}
    		
    		System.out.println("结束");
    		
    	}catch(Exception e){
    		
    		System.out.println(e.getMessage());
    	}

    }
    /**
     */
    public static class Table{
    	
    	//表名
    	private String tableName;
    	//列
    	private String columnStr;
    	
    	private String keyName;
    	//类型
    	private String typeStr;
    	//备注 
    	private String contentStr;
    	
		public String getTableName() {
			return tableName;
		}

		public void setTableName(String tableName) {
			this.tableName = tableName;
		}

		public String getColumnStr() {
			return columnStr;
		}

		public void setColumnStr(String columnStr) {
			this.columnStr = columnStr;
		}

		public String getKeyName() {
			return keyName;
		}

		public void setKeyName(String keyName) {
			this.keyName = keyName;
		}

		public String getTypeStr() {
			return typeStr;
		}

		public void setTypeStr(String typeStr) {
			this.typeStr = typeStr;
		}

		public String getContentStr() {
			return contentStr;
		}

		public void setContentStr(String contentStr) {
			this.contentStr = contentStr;
		}

		@Override
		public String toString() {
			return "Table [tableName=" + tableName + ", columnStr=" + columnStr + ", keyName=" + keyName + ", typeStr="
					+ typeStr + ", contentStr=" + contentStr + "]";
		}
    	
    }

    /**
     * 导入excel
     * @param workbook
     * @param num
     * @return
     */
    public static List<Table> importExcel(Workbook workbook,int num){
    	
    	List<Table> list = new ArrayList<Table>();
    	Sheet[] sheet = workbook.getSheets();
    	//工作签
    	for(int i = 0; i < sheet.length ; i++){
    		if( i  >= num){
    			Table table = new Table();
    			//数据库 EXCEL 标签
    			Sheet shet = workbook.getSheet(i);
    			//列 行 表名
    			 Cell cell=shet.getCell(0, 3);
    			 
    			 table.setTableName(cell.getContents());
    			 
    			 int rows = shet.getRows();
    			 //
    			 StringBuffer columns = new StringBuffer();
    			 StringBuffer types = new StringBuffer();
    			 StringBuffer contents = new StringBuffer();
    			 //循环行
    			 for(int j = 0; j < rows; j++){
    				 if(j >= 6){
    					 //字段
    					 Cell cel10 = null;
    					 cel10 = shet.getCell(2, j);
    					 //类型
    					 Cell cel11 = null;
    					 cel11 = shet.getCell(3, j);
    					 //长度
    					 Cell cel12 = null;
    					 cel12 = shet.getCell(4, j);
    					 //备注
    					 Cell cel13 = null;
    					 cel13 = shet.getCell(1, j);
    					 if(cel10.getContents() != null && !cel10.getContents().equals("")){
    						 columns.append(",").append(cel10.getContents());
    						 types.append(",").append(cel11.getContents());
    						 if(cel12.getContents() != null && !cel12.getContents().equals("")){
    							 types.append("(").append(cel12.getContents()).append(")");
    						 }
    						 contents.append(",").append(cel13.getContents());
    					 }
    					//字段
    					 table.setColumnStr(columns.toString().substring(1));
    					//类型
    					 table.setTypeStr(types.toString().substring(1));
    					 //备注
    					 table.setContentStr(contents.toString().substring(1));
    				 }
    			 }
    			 //返回集合
    			 list.add(table);
    		}
    	}
    	workbook.close();
    	return  list;
    }
    
    

    /**
     * 生成 创键表语句
     * @param table
     * @param column
     * @param key
     * @param type
     * @param content
     * @return
     */
    public static String createSql(String table,String column,String key,String type,String content){

        String head = "CREATE TABLE".toUpperCase(); //大写
        //创键 表名空 error
        if(table != null && table.length() > 0){
            //创键 列空 error
            if(column != null && column.length() > 0){
                //sql语句
                StringBuffer sql = new StringBuffer();
                //列数组   类型数组  备注数组
                String[] columnArr = new String[]{};
                String[] typeArr = new String[]{};
                String[] contentArr = new String[]{};
                try{
                    columnArr = column.split(",");
                    //如果type不为空 比对column 分割后的长度不等 error
                    if(type != null && type.length() > 0){
                        typeArr = type.split(",");
                        if(columnArr.length != typeArr.length){
                            return  "异常:列数量与类型数量不匹配";
                        }
                    }
                    //如果content不为空 比对column 分割后的长度不等 error
                    if(content != null && content.length() > 0){
                        contentArr = content.split(",");
                        if(columnArr.length != contentArr.length){
                            return  "异常:列数量与备注数量不匹配";
                        }
                    }
                    sql.append(head).append(" ");
                    //表名
                    sql.append(table.toLowerCase()).append(" (");
                    for(int i = 0;i < columnArr.length;i++){

                        if(i != 0)
                            sql.append(",");
                        //字段名
                        sql.append(columnArr[i]).append(" ");
                        //类型
                        if(typeArr.length > 0){
                            sql.append(typeArr[i].toUpperCase()).append(" ");
                        }else{
                            sql.append("INT ");
                        }
                         //是否是主键
                        if(key != null && key.length() > 0 && key.toLowerCase().equals(columnArr[i].toLowerCase())){
                            sql.append("PRIMARY KEY ");
                        }else{
                             //默认值空
                            sql.append("DEFAULT NULL ");
                        }
                        //备注
                        if(contentArr.length > 0)
                            sql.append("COMMENT '").append(contentArr[i]).append("' ");

                    }
                    sql.append(");");

                }catch (Exception e){
                    return  "异常:请修正程序 ERROR:" + e.getMessage();
                }
                //返回sql语句
                return sql.toString();
            }else{
                return "异常:创键表至少一列";
            }
        }else{
            return "异常:表名必须";
        }
    }
    /**
     * 生成 创键表语句
     * @param table
     * @param column
     * @param key
     * @param type
     * @return
     */
    public static String createSql(String table,String column,String key,String type){return createSql(table,column,key,type,null);}
    /**
     * 生成 创键表语句
     * @param table
     * @param column
     * @param key
     * @return
     */
    public static String createSql(String table,String column,String key){return createSql(table,column,key,null,null);}
    /**
     * 生成 创键表语句
     * @param table
     * @param column
     * @return
     */
    public static String createSql(String table,String column){return createSql(table,column,null,null,null);}  

}
